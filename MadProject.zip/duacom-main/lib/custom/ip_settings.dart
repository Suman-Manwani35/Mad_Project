const kPrimaryId = '192.168.0.56';
