package com.example.duas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
